import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthInit } from './hooks/useAuth';
import { AuthGuard } from './components/auth/AuthGuard';
import { AppShell } from './components/layout/AppShell';

import { LoginPage } from './pages/auth/LoginPage';
import { RegisterPage } from './pages/auth/RegisterPage';
import { DashboardPage } from './pages/DashboardPage';
import { UploadPage } from './pages/UploadPage';
import { AnalysisPage } from './pages/AnalysisPage';
import { DrillsPage } from './pages/DrillsPage';
import { ProfilePage } from './pages/ProfilePage';

export function App() {
  useAuthInit();

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        <Route
          path="/dashboard"
          element={
            <AuthGuard>
              <AppShell>
                <DashboardPage />
              </AppShell>
            </AuthGuard>
          }
        />
        <Route
          path="/upload"
          element={
            <AuthGuard>
              <AppShell>
                <UploadPage />
              </AppShell>
            </AuthGuard>
          }
        />
        <Route
          path="/analysis/:sessionId"
          element={
            <AuthGuard>
              <AppShell>
                <AnalysisPage />
              </AppShell>
            </AuthGuard>
          }
        />
        <Route
          path="/drills"
          element={
            <AuthGuard>
              <AppShell>
                <DrillsPage />
              </AppShell>
            </AuthGuard>
          }
        />
        <Route
          path="/profile"
          element={
            <AuthGuard>
              <AppShell>
                <ProfilePage />
              </AppShell>
            </AuthGuard>
          }
        />

        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
