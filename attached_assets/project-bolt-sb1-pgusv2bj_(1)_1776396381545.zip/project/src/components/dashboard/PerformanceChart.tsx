import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Card, CardHeader, CardContent } from '../ui/Card';
import type { ProgressMetric } from '../../types';

interface PerformanceChartProps {
  metrics: ProgressMetric[];
}

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; name: string; color: string }>; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 shadow-xl">
      <p className="text-zinc-400 text-xs mb-1.5">{label}</p>
      {payload.map((p) => (
        <p key={p.name} className="text-sm font-semibold" style={{ color: p.color }}>
          {p.name}: {Math.round(p.value)}
        </p>
      ))}
    </div>
  );
};

export function PerformanceChart({ metrics }: PerformanceChartProps) {
  const data = metrics.map((m) => ({
    date: new Date(m.session_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    Overall: m.overall_score,
    Offense: m.offense_score,
    Defense: m.defense_score,
    Footwork: m.footwork_score,
  }));

  if (data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <h3 className="text-sm font-semibold text-zinc-100">Performance Over Time</h3>
        </CardHeader>
        <CardContent>
          <div className="h-48 flex items-center justify-center text-zinc-500 text-sm">
            No performance data yet. Analyze your first match to see trends.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-zinc-100">Performance Over Time</h3>
          <div className="flex items-center gap-4 text-xs">
            {[
              { label: 'Overall', color: '#ef4444' },
              { label: 'Offense', color: '#f97316' },
              { label: 'Defense', color: '#3b82f6' },
              { label: 'Footwork', color: '#22c55e' },
            ].map(({ label, color }) => (
              <div key={label} className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
                <span className="text-zinc-400">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={data} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
            <XAxis dataKey="date" tick={{ fill: '#71717a', fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis domain={[0, 100]} tick={{ fill: '#71717a', fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Line type="monotone" dataKey="Overall" stroke="#ef4444" strokeWidth={2} dot={{ fill: '#ef4444', r: 3 }} activeDot={{ r: 5 }} />
            <Line type="monotone" dataKey="Offense" stroke="#f97316" strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
            <Line type="monotone" dataKey="Defense" stroke="#3b82f6" strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
            <Line type="monotone" dataKey="Footwork" stroke="#22c55e" strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
