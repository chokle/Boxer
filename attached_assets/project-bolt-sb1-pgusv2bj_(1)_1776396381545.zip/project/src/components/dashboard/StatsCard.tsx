import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { Card, CardContent } from '../ui/Card';
import { cn } from '../../lib/utils';

interface StatsCardProps {
  label: string;
  value: string | number;
  delta?: number;
  icon: React.ReactNode;
  suffix?: string;
}

export function StatsCard({ label, value, delta, icon, suffix }: StatsCardProps) {
  return (
    <Card className="relative overflow-hidden">
      <CardContent>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-zinc-500 text-xs font-medium uppercase tracking-wider mb-2">{label}</p>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold text-white">{value}</span>
              {suffix && <span className="text-zinc-400 text-sm">{suffix}</span>}
            </div>
            {delta !== undefined && (
              <div className={cn(
                'flex items-center gap-1 mt-1.5 text-xs font-medium',
                delta > 0 ? 'text-emerald-400' : delta < 0 ? 'text-red-400' : 'text-zinc-500'
              )}>
                {delta > 0 ? <TrendingUp className="w-3 h-3" /> : delta < 0 ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                {delta > 0 ? '+' : ''}{delta} from last session
              </div>
            )}
          </div>
          <div className="w-10 h-10 bg-red-600/10 rounded-lg flex items-center justify-center flex-shrink-0 border border-red-600/20">
            <span className="text-red-400">{icon}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
