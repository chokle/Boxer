import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Upload, ChartBar as BarChart2, Dumbbell, User } from 'lucide-react';
import { cn } from '../../lib/utils';

const navItems = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Home' },
  { to: '/upload', icon: Upload, label: 'Analyze' },
  { to: '/analysis', icon: BarChart2, label: 'Sessions' },
  { to: '/drills', icon: Dumbbell, label: 'Drills' },
  { to: '/profile', icon: User, label: 'Profile' },
];

export function MobileNav() {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-zinc-900 border-t border-zinc-800 z-30 safe-area-pb">
      <div className="flex">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) => cn(
              'flex-1 flex flex-col items-center gap-1 py-3 text-xs font-medium transition-colors',
              isActive ? 'text-red-400' : 'text-zinc-500'
            )}
          >
            {({ isActive }) => (
              <>
                <Icon className={cn('w-5 h-5', isActive ? 'text-red-400' : 'text-zinc-500')} />
                {label}
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
