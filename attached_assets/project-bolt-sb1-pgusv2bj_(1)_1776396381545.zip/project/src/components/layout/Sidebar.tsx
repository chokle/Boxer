import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Upload, ChartBar as BarChart2, Dumbbell, User, LogOut, Target } from 'lucide-react';
import { cn } from '../../lib/utils';
import { useAuth } from '../../hooks/useAuth';

const navItems = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/upload', icon: Upload, label: 'Analyze Match' },
  { to: '/analysis', icon: BarChart2, label: 'Analysis' },
  { to: '/drills', icon: Dumbbell, label: 'Drills' },
  { to: '/profile', icon: User, label: 'Profile' },
];

export function Sidebar() {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <aside className="hidden md:flex flex-col w-60 h-screen bg-zinc-900 border-r border-zinc-800 fixed left-0 top-0 z-30">
      <div className="px-5 py-5 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center flex-shrink-0 shadow-md shadow-red-900/40">
            <Target className="w-4 h-4 text-white" />
          </div>
          <div>
            <span className="text-white font-bold text-sm tracking-wide">BoxCoach AI</span>
            <p className="text-zinc-500 text-xs">Elite Performance</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) => cn(
              'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 group',
              isActive
                ? 'bg-red-600/15 text-red-400 border border-red-600/20'
                : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 border border-transparent'
            )}
          >
            {({ isActive }) => (
              <>
                <Icon className={cn('w-4 h-4 flex-shrink-0', isActive ? 'text-red-400' : 'text-zinc-500 group-hover:text-zinc-300')} />
                {label}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="px-3 py-4 border-t border-zinc-800">
        {profile && (
          <div className="px-3 py-2.5 mb-1">
            <p className="text-zinc-100 text-sm font-medium truncate">{profile.name || 'Boxer'}</p>
            <p className="text-zinc-500 text-xs">{profile.weight_class} · {profile.stance}</p>
          </div>
        )}
        <button
          onClick={handleSignOut}
          className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm font-medium text-zinc-500 hover:text-red-400 hover:bg-red-900/10 transition-all duration-150 border border-transparent"
        >
          <LogOut className="w-4 h-4 flex-shrink-0" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
