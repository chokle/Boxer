import { cn } from '../../lib/utils';
import type { SessionStatus, DrillDifficulty, DrillCategory } from '../../types';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'status' | 'difficulty' | 'category';
  status?: SessionStatus;
  difficulty?: DrillDifficulty;
  category?: DrillCategory;
  className?: string;
}

const statusStyles: Record<SessionStatus, string> = {
  pending: 'bg-zinc-800 text-zinc-400 border-zinc-700',
  processing: 'bg-amber-900/30 text-amber-400 border-amber-700/50',
  completed: 'bg-emerald-900/30 text-emerald-400 border-emerald-700/50',
  failed: 'bg-red-900/30 text-red-400 border-red-700/50',
};

const difficultyStyles: Record<DrillDifficulty, string> = {
  Easy: 'bg-emerald-900/30 text-emerald-400 border-emerald-700/50',
  Medium: 'bg-amber-900/30 text-amber-400 border-amber-700/50',
  Hard: 'bg-red-900/30 text-red-400 border-red-700/50',
};

const categoryStyles: Record<DrillCategory, string> = {
  footwork: 'bg-blue-900/30 text-blue-400 border-blue-700/50',
  offense: 'bg-red-900/30 text-red-400 border-red-700/50',
  defense: 'bg-zinc-800 text-zinc-300 border-zinc-700',
  stamina: 'bg-orange-900/30 text-orange-400 border-orange-700/50',
  combination: 'bg-purple-900/30 text-purple-400 border-purple-700/50',
  general: 'bg-zinc-800 text-zinc-400 border-zinc-700',
};

export function Badge({ children, variant = 'default', status, difficulty, category, className }: BadgeProps) {
  let styles = 'bg-zinc-800 text-zinc-300 border-zinc-700';

  if (variant === 'status' && status) styles = statusStyles[status];
  if (variant === 'difficulty' && difficulty) styles = difficultyStyles[difficulty];
  if (variant === 'category' && category) styles = categoryStyles[category];

  return (
    <span
      className={cn(
        'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
        styles,
        className
      )}
    >
      {children}
    </span>
  );
}
