import { useEffect, useRef } from 'react';
import { getScoreColor, getScoreLabel } from '../../lib/utils';

interface ScoreRingProps {
  score: number;
  size?: number;
  label?: string;
  showLabel?: boolean;
  animate?: boolean;
}

export function ScoreRing({ score, size = 120, label, showLabel = true, animate = true }: ScoreRingProps) {
  const circleRef = useRef<SVGCircleElement>(null);
  const radius = 45;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  const color = getScoreColor(score);
  const scoreLabel = label ?? getScoreLabel(score);

  useEffect(() => {
    if (!animate || !circleRef.current) return;
    circleRef.current.style.setProperty('--target-offset', `${offset}px`);
    circleRef.current.style.strokeDashoffset = `${circumference}`;
    const frame = requestAnimationFrame(() => {
      if (circleRef.current) {
        circleRef.current.style.transition = 'stroke-dashoffset 1.2s cubic-bezier(0.4, 0, 0.2, 1)';
        circleRef.current.style.strokeDashoffset = `${offset}`;
      }
    });
    return () => cancelAnimationFrame(frame);
  }, [score, offset, circumference, animate]);

  return (
    <div className="flex flex-col items-center gap-1.5">
      <svg width={size} height={size} viewBox="0 0 100 100" style={{ transform: 'rotate(-90deg)' }}>
        <circle
          cx="50" cy="50" r={radius}
          fill="none"
          stroke="#27272a"
          strokeWidth="8"
        />
        <circle
          ref={circleRef}
          cx="50" cy="50" r={radius}
          fill="none"
          stroke={color}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={animate ? circumference : offset}
        />
      </svg>
      <div className="flex flex-col items-center -mt-1" style={{ marginTop: `-${size * 0.55}px`, position: 'relative', zIndex: 1 }}>
        <span className="text-2xl font-bold text-white leading-none" style={{ fontSize: size * 0.22 }}>
          {Math.round(score)}
        </span>
        {showLabel && (
          <span className="text-zinc-500 font-medium" style={{ fontSize: size * 0.095 }}>
            {scoreLabel}
          </span>
        )}
      </div>
    </div>
  );
}

export function ScoreBar({ label, score }: { label: string; score: number }) {
  const color = getScoreColor(score);
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between items-center">
        <span className="text-sm text-zinc-400">{label}</span>
        <span className="text-sm font-semibold text-white">{Math.round(score)}</span>
      </div>
      <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-1000 ease-out"
          style={{ width: `${score}%`, backgroundColor: color }}
        />
      </div>
    </div>
  );
}
