import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { MatchSession, PerformanceAnalysis } from '../types';

export function useSessionDetail(sessionId: string | undefined) {
  const [session, setSession] = useState<MatchSession | null>(null);
  const [analysis, setAnalysis] = useState<PerformanceAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!sessionId) return;
    setLoading(true);

    const fetchData = async () => {
      const { data: sessionData, error: sessionErr } = await supabase
        .from('match_sessions')
        .select('*')
        .eq('id', sessionId)
        .maybeSingle();

      if (sessionErr) { setError(sessionErr.message); setLoading(false); return; }
      setSession(sessionData as MatchSession);

      const { data: analysisData } = await supabase
        .from('performance_analyses')
        .select('*, drill_recommendations(*)')
        .eq('session_id', sessionId)
        .maybeSingle();

      setAnalysis(analysisData as PerformanceAnalysis | null);
      setLoading(false);
    };

    fetchData();
  }, [sessionId]);

  return { session, analysis, loading, error };
}

export function useSessionSubscription(sessionId: string | undefined, onComplete: () => void) {
  useEffect(() => {
    if (!sessionId) return;

    const channel = supabase
      .channel(`session-${sessionId}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'match_sessions',
        filter: `id=eq.${sessionId}`,
      }, (payload) => {
        const updated = payload.new as { status: string };
        if (updated.status === 'completed' || updated.status === 'failed') {
          onComplete();
        }
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [sessionId, onComplete]);
}
