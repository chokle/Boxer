import { useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/authStore';

export function useAuthInit() {
  const { setUser, setSession, setLoading, setInitialized, fetchProfile } = useAuthStore();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id);
      }
      setLoading(false);
      setInitialized(true);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        (async () => {
          await fetchProfile(session.user.id);
        })();
      } else {
        useAuthStore.getState().setProfile(null);
      }
      setLoading(false);
      setInitialized(true);
    });

    return () => subscription.unsubscribe();
  }, []);
}

export function useAuth() {
  return useAuthStore((state) => ({
    user: state.user,
    session: state.session,
    profile: state.profile,
    loading: state.loading,
    initialized: state.initialized,
    signOut: state.signOut,
    fetchProfile: state.fetchProfile,
  }));
}
