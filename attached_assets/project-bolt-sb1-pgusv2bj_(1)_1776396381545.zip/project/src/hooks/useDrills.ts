import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { DrillRecommendation } from '../types';

export function useDrills(boxerId: string | undefined) {
  const [drills, setDrills] = useState<DrillRecommendation[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchDrills = useCallback(async () => {
    if (!boxerId) return;
    setLoading(true);
    const { data } = await supabase
      .from('drill_recommendations')
      .select('*')
      .eq('boxer_id', boxerId)
      .order('created_at', { ascending: false });

    setDrills((data as DrillRecommendation[]) ?? []);
    setLoading(false);
  }, [boxerId]);

  useEffect(() => {
    fetchDrills();
  }, [fetchDrills]);

  const toggleComplete = async (drillId: string, completed: boolean) => {
    await supabase
      .from('drill_recommendations')
      .update({ completed })
      .eq('id', drillId);

    setDrills((prev) =>
      prev.map((d) => (d.id === drillId ? { ...d, completed } : d))
    );
  };

  const pendingCount = drills.filter((d) => !d.completed).length;
  const completedCount = drills.filter((d) => d.completed).length;

  return { drills, loading, toggleComplete, pendingCount, completedCount, refetch: fetchDrills };
}
