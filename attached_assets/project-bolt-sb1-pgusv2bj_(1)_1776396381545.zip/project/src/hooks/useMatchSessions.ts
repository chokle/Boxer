import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { MatchSession, BoxerProfile, AnalyzeMatchRequest } from '../types';

export function useMatchSessions(boxerId: string | undefined) {
  const [sessions, setSessions] = useState<MatchSession[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSessions = useCallback(async () => {
    if (!boxerId) return;
    setLoading(true);
    const { data, error: err } = await supabase
      .from('match_sessions')
      .select('*, performance_analyses(*)')
      .eq('boxer_id', boxerId)
      .order('created_at', { ascending: false });

    if (err) setError(err.message);
    else setSessions((data as MatchSession[]) ?? []);
    setLoading(false);
  }, [boxerId]);

  useEffect(() => {
    fetchSessions();
  }, [fetchSessions]);

  const createSession = async (
    payload: Omit<MatchSession, 'id' | 'created_at' | 'status' | 'video_url' | 'performance_analyses'>
  ) => {
    const { data, error: err } = await supabase
      .from('match_sessions')
      .insert({ ...payload, status: 'pending' })
      .select()
      .single();
    if (err) throw new Error(err.message);
    return data as MatchSession;
  };

  const triggerAnalysis = async (request: AnalyzeMatchRequest, profile: BoxerProfile) => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
    const { data: { session } } = await supabase.auth.getSession();

    const response = await fetch(`${supabaseUrl}/functions/v1/analyze-match`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${session?.access_token ?? supabaseAnonKey}`,
        'Content-Type': 'application/json',
        'Apikey': supabaseAnonKey,
      },
      body: JSON.stringify({ ...request, boxer_profile: profile }),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error ?? 'Analysis failed');
    }

    return response.json();
  };

  return { sessions, loading, error, fetchSessions, createSession, triggerAnalysis };
}
