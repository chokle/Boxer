import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { ProgressMetric } from '../types';

export function useProgressMetrics(boxerId: string | undefined, limit = 10) {
  const [metrics, setMetrics] = useState<ProgressMetric[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchMetrics = useCallback(async () => {
    if (!boxerId) return;
    setLoading(true);
    const { data } = await supabase
      .from('progress_metrics')
      .select('*')
      .eq('boxer_id', boxerId)
      .order('session_date', { ascending: true })
      .limit(limit);

    setMetrics((data as ProgressMetric[]) ?? []);
    setLoading(false);
  }, [boxerId, limit]);

  useEffect(() => {
    fetchMetrics();
  }, [fetchMetrics]);

  return { metrics, loading, refetch: fetchMetrics };
}
