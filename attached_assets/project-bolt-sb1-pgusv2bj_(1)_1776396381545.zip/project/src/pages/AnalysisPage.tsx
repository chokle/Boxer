import { useParams } from 'react-router-dom';
import { useSessionDetail, useSessionSubscription } from '../hooks/useAnalysis';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { ScoreRing, ScoreBar } from '../components/ui/ScoreRing';
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import { formatDate } from '../lib/utils';
import { useState, useCallback } from 'react';

export function AnalysisPage() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const { session, analysis, loading } = useSessionDetail(sessionId);
  const [refreshKey, setRefreshKey] = useState(0);

  const handleComplete = useCallback(() => {
    setRefreshKey((k) => k + 1);
  }, []);

  useSessionSubscription(sessionId, handleComplete);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!session || !analysis) {
    return (
      <div className="text-center py-12">
        <p className="text-zinc-400">Analysis not found or still processing...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in" key={refreshKey}>
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-1">{session.title}</h1>
          <p className="text-zinc-400">{formatDate(session.created_at)}</p>
        </div>
        <Badge variant="status" status={session.status}>{session.status}</Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <Card>
            <CardContent className="pt-6 flex justify-center">
              <ScoreRing score={analysis.overall_score} size={140} showLabel={true} animate={false} />
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <h2 className="text-lg font-semibold text-white">Performance Breakdown</h2>
            </CardHeader>
            <CardContent className="space-y-4">
              <ScoreBar label="Stance" score={analysis.stance_score} />
              <ScoreBar label="Offense" score={analysis.offense_score} />
              <ScoreBar label="Defense" score={analysis.defense_score} />
              <ScoreBar label="Footwork" score={analysis.footwork_score} />
              <ScoreBar label="Combinations" score={analysis.combination_score} />
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-white">Tactical Summary</h2>
        </CardHeader>
        <CardContent>
          <p className="text-zinc-300 leading-relaxed">{analysis.tactical_summary}</p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold text-white">Key Strengths</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {analysis.key_strengths?.map((strength: string, i: number) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-emerald-400 flex-shrink-0 mt-1">✓</span>
                  <p className="text-zinc-300 text-sm">{strength}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold text-white">Areas for Improvement</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {analysis.improvement_areas?.map((area: string, i: number) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-orange-400 flex-shrink-0 mt-1">→</span>
                  <p className="text-zinc-300 text-sm">{area}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold text-white">Stance Feedback</h3>
          </CardHeader>
          <CardContent>
            <p className="text-zinc-300 text-sm leading-relaxed">{analysis.stance_feedback}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold text-white">Offense Analysis</h3>
          </CardHeader>
          <CardContent>
            <p className="text-zinc-300 text-sm leading-relaxed">{analysis.offense_feedback}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold text-white">Defense Technique</h3>
          </CardHeader>
          <CardContent>
            <p className="text-zinc-300 text-sm leading-relaxed">{analysis.defense_feedback}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold text-white">Footwork & Movement</h3>
          </CardHeader>
          <CardContent>
            <p className="text-zinc-300 text-sm leading-relaxed">{analysis.footwork_feedback}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold text-white">Combinations</h3>
          </CardHeader>
          <CardContent>
            <p className="text-zinc-300 text-sm leading-relaxed">{analysis.combination_feedback}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold text-white">Punch Statistics</h3>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-xs text-zinc-500 uppercase tracking-wider mb-1">Punches Thrown</p>
              <p className="text-lg font-semibold text-white">{analysis.punches_thrown}</p>
            </div>
            <div>
              <p className="text-xs text-zinc-500 uppercase tracking-wider mb-1">Punches Landed</p>
              <p className="text-lg font-semibold text-white">{analysis.punches_landed}</p>
            </div>
            <div>
              <p className="text-xs text-zinc-500 uppercase tracking-wider mb-1">Accuracy</p>
              <p className="text-lg font-semibold text-white">{Math.round(analysis.shot_accuracy)}%</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {analysis.drill_recommendations && analysis.drill_recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <h2 className="text-lg font-semibold text-white">Recommended Drills</h2>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analysis.drill_recommendations.map((drill) => (
                <div key={drill.id} className="p-3 bg-zinc-800/50 rounded-lg border border-zinc-700">
                  <div className="flex items-start justify-between mb-1.5">
                    <h4 className="font-semibold text-white text-sm">{drill.name}</h4>
                    <div className="flex gap-2">
                      <Badge variant="category" category={drill.category}>{drill.category}</Badge>
                      <Badge variant="difficulty" difficulty={drill.difficulty}>{drill.difficulty}</Badge>
                    </div>
                  </div>
                  <p className="text-zinc-400 text-xs mb-2">{drill.description}</p>
                  <div className="flex gap-4 text-xs text-zinc-500">
                    {drill.duration && <span>⏱️ {drill.duration}</span>}
                    {drill.focus_area && <span>🎯 {drill.focus_area}</span>}
                    {drill.reps && <span>💪 {drill.reps}</span>}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
