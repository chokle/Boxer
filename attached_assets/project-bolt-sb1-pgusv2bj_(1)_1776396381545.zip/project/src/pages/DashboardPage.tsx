import { useAuth } from '../hooks/useAuth';
import { useProgressMetrics } from '../hooks/useProgressMetrics';
import { useDrills } from '../hooks/useDrills';
import { StatsCard } from '../components/dashboard/StatsCard';
import { PerformanceChart } from '../components/dashboard/PerformanceChart';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Activity, Zap, TrendingUp, Clock } from 'lucide-react';
import { formatDate } from '../lib/utils';
import { useNavigate } from 'react-router-dom';

export function DashboardPage() {
  const { profile } = useAuth();
  const { metrics, loading } = useProgressMetrics(profile?.id, 10);
  const { pendingCount, completedCount } = useDrills(profile?.id);
  const navigate = useNavigate();

  const latestMetric = metrics[metrics.length - 1];
  const previousMetric = metrics[metrics.length - 2];
  const overallDelta = latestMetric && previousMetric ? Math.round(latestMetric.overall_score - previousMetric.overall_score) : undefined;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold text-white">Welcome back, {profile?.name || 'Boxer'}</h1>
        <p className="text-zinc-400">{profile?.stance} stance · {profile?.experience_level} · {profile?.weight_class}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          label="Overall Score"
          value={latestMetric ? Math.round(latestMetric.overall_score) : '—'}
          delta={overallDelta}
          icon={<TrendingUp className="w-4 h-4" />}
        />
        <StatsCard
          label="Active Drills"
          value={pendingCount}
          icon={<Zap className="w-4 h-4" />}
        />
        <StatsCard
          label="Drills Completed"
          value={completedCount}
          icon={<Activity className="w-4 h-4" />}
        />
        <StatsCard
          label="Last Session"
          value={latestMetric ? formatDate(latestMetric.session_date) : '—'}
          icon={<Clock className="w-4 h-4" />}
        />
      </div>

      <PerformanceChart metrics={metrics} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold text-zinc-100">Quick Actions</h3>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                onClick={() => navigate('/upload')}
                className="w-full"
                size="lg"
              >
                Analyze New Match
              </Button>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  onClick={() => navigate('/drills')}
                  variant="secondary"
                  className="w-full"
                >
                  Start Drill Session
                </Button>
                <Button
                  onClick={() => navigate('/analysis')}
                  variant="secondary"
                  className="w-full"
                >
                  View History
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold text-zinc-100">Profile Stats</h3>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-xs text-zinc-500 uppercase tracking-wider mb-1">Reach</p>
              <p className="text-lg font-semibold text-white">{profile?.reach_inches || '—'}"</p>
            </div>
            <div>
              <p className="text-xs text-zinc-500 uppercase tracking-wider mb-1">Age</p>
              <p className="text-lg font-semibold text-white">{profile?.age || '—'}</p>
            </div>
            <Button
              onClick={() => navigate('/profile')}
              variant="ghost"
              className="w-full"
              size="sm"
            >
              Edit Profile
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
