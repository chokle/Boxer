import { useAuth } from '../hooks/useAuth';
import { useDrills } from '../hooks/useDrills';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Dumbbell, CircleCheck as CheckCircle2, Circle } from 'lucide-react';

export function DrillsPage() {
  const { profile } = useAuth();
  const { drills, toggleComplete, pendingCount, completedCount } = useDrills(profile?.id);

  const activeDrills = drills.filter((d) => !d.completed);
  const completedDrills = drills.filter((d) => d.completed);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold text-white flex items-center gap-2">
          <Dumbbell className="w-8 h-8 text-red-400" />
          Training Drills
        </h1>
        <p className="text-zinc-400">Personalized exercises from your match analyses</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-white">{pendingCount}</p>
              <p className="text-zinc-400 text-sm mt-1">Active Drills</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-emerald-400">{completedCount}</p>
              <p className="text-zinc-400 text-sm mt-1">Completed</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-zinc-400">{drills.length}</p>
              <p className="text-zinc-400 text-sm mt-1">Total Drills</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {drills.length === 0 ? (
        <Card>
          <CardContent className="pt-12 pb-12 text-center">
            <Dumbbell className="w-12 h-12 text-zinc-700 mx-auto mb-4" />
            <p className="text-zinc-400 mb-1">No drills yet</p>
            <p className="text-zinc-500 text-sm">Analyze your first match to get personalized drill recommendations</p>
          </CardContent>
        </Card>
      ) : (
        <>
          {pendingCount > 0 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                  <Circle className="w-5 h-5 text-red-400" />
                  Active Drills
                </h2>
                <div className="grid gap-3">
                  {activeDrills.map((drill) => (
                    <Card key={drill.id} className="hover">
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-white mb-1.5">{drill.name}</h3>
                            <p className="text-zinc-400 text-sm mb-2.5 leading-relaxed">{drill.description}</p>
                            <div className="flex flex-wrap gap-2">
                              <Badge variant="category" category={drill.category}>{drill.category}</Badge>
                              <Badge variant="difficulty" difficulty={drill.difficulty}>{drill.difficulty}</Badge>
                              {drill.duration && <Badge>{drill.duration}</Badge>}
                            </div>
                            {drill.focus_area && (
                              <p className="text-xs text-zinc-500 mt-2">Focus: {drill.focus_area}</p>
                            )}
                            {drill.reps && (
                              <p className="text-xs text-zinc-500">Reps: {drill.reps}</p>
                            )}
                          </div>
                          <Button
                            onClick={() => toggleComplete(drill.id, true)}
                            variant="secondary"
                            size="sm"
                            className="flex-shrink-0"
                          >
                            Complete
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}

          {completedCount > 0 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  Completed Drills
                </h2>
                <div className="grid gap-3">
                  {completedDrills.map((drill) => (
                    <Card key={drill.id} className="opacity-70">
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                              <h3 className="font-semibold text-zinc-300">{drill.name}</h3>
                            </div>
                            <p className="text-zinc-500 text-sm mb-2.5">{drill.description}</p>
                            <div className="flex flex-wrap gap-2">
                              <Badge variant="category" category={drill.category}>{drill.category}</Badge>
                              <Badge variant="difficulty" difficulty={drill.difficulty}>{drill.difficulty}</Badge>
                            </div>
                          </div>
                          <Button
                            onClick={() => toggleComplete(drill.id, false)}
                            variant="ghost"
                            size="sm"
                            className="flex-shrink-0"
                          >
                            Undo
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
