import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { User } from 'lucide-react';
import type { ExperienceLevel, Stance } from '../types';

export function ProfilePage() {
  const { profile, fetchProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState({
    name: profile?.name || '',
    age: profile?.age || '',
    reach_inches: profile?.reach_inches || '',
    weight_class: profile?.weight_class || 'Middleweight',
    experience_level: profile?.experience_level || 'Intermediate' as ExperienceLevel,
    stance: profile?.stance || 'Orthodox' as Stance,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(false);
    setLoading(true);

    const { error: err } = await supabase
      .from('boxer_profiles')
      .update({
        name: formData.name,
        age: formData.age ? parseInt(formData.age) : null,
        reach_inches: formData.reach_inches ? parseInt(formData.reach_inches) : null,
        weight_class: formData.weight_class,
        experience_level: formData.experience_level,
        stance: formData.stance,
      })
      .eq('id', profile?.id);

    if (err) {
      setError(err.message);
    } else {
      setSuccess(true);
      if (profile?.user_id) await fetchProfile(profile.user_id);
      setTimeout(() => setSuccess(false), 3000);
    }
    setLoading(false);
  };

  return (
    <div className="max-w-2xl space-y-6 animate-fade-in">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold text-white flex items-center gap-2">
          <User className="w-8 h-8 text-red-400" />
          Boxer Profile
        </h1>
        <p className="text-zinc-400">Update your boxing profile and stats</p>
      </div>

      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-white">Personal Information</h2>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Full Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">Age</label>
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">Reach (inches)</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={formData.reach_inches}
                  onChange={(e) => setFormData({ ...formData, reach_inches: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">Weight Class</label>
                <select
                  value={formData.weight_class}
                  onChange={(e) => setFormData({ ...formData, weight_class: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors"
                >
                  <option>Mini Flyweight</option>
                  <option>Flyweight</option>
                  <option>Bantamweight</option>
                  <option>Featherweight</option>
                  <option>Lightweight</option>
                  <option>Welterweight</option>
                  <option>Middleweight</option>
                  <option>Light Heavyweight</option>
                  <option>Heavyweight</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">Experience Level</label>
                <select
                  value={formData.experience_level}
                  onChange={(e) => setFormData({ ...formData, experience_level: e.target.value as ExperienceLevel })}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors"
                >
                  <option>Beginner</option>
                  <option>Intermediate</option>
                  <option>Advanced</option>
                  <option>Pro</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Stance</label>
              <select
                value={formData.stance}
                onChange={(e) => setFormData({ ...formData, stance: e.target.value as Stance })}
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors"
              >
                <option>Orthodox</option>
                <option>Southpaw</option>
                <option>Switch</option>
              </select>
            </div>

            {error && (
              <div className="bg-red-900/20 border border-red-800 rounded-lg px-3 py-2.5 text-red-400 text-sm">
                {error}
              </div>
            )}

            {success && (
              <div className="bg-emerald-900/20 border border-emerald-800 rounded-lg px-3 py-2.5 text-emerald-400 text-sm">
                Profile updated successfully
              </div>
            )}

            <Button type="submit" loading={loading} className="w-full" size="lg">
              Save Changes
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
