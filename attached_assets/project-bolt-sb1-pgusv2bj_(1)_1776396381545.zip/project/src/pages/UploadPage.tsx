import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useMatchSessions } from '../hooks/useMatchSessions';
import { Button } from '../components/ui/Button';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import { Upload, CircleCheck as CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function UploadPage() {
  const { profile } = useAuth();
  const { createSession, triggerAnalysis } = useMatchSessions(profile?.id);
  const navigate = useNavigate();

  const [step, setStep] = useState<'form' | 'uploading' | 'success'>(profile ? 'form' : 'uploading');
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    match_context: 'training',
    opponent_style: 'balanced',
    matchDescription: '',
  });
  const [loading, setLoading] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!profile) return <div>Loading...</div>;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    setStep('uploading');

    try {
      const newSession = await createSession({
        boxer_id: profile.id,
        title: formData.title,
        description: formData.description,
        video_url: '',
        match_context: formData.match_context,
        opponent_style: formData.opponent_style,
      });

      setSessionId(newSession.id);

      await triggerAnalysis({
        session_id: newSession.id,
        boxer_profile: profile,
        match_context: formData.match_context,
        opponent_style: formData.opponent_style,
        match_description: formData.matchDescription,
      }, profile);

      setStep('success');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to analyze match');
      setStep('form');
      setLoading(false);
    }
  };

  if (step === 'uploading') {
    return (
      <div className="max-w-2xl mx-auto py-12 text-center animate-fade-in">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-red-600/15 rounded-full mb-6 border border-red-600/20">
          <LoadingSpinner size="lg" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Analyzing Your Match</h2>
        <p className="text-zinc-400 mb-6">Our AI coach is reviewing your performance. This may take a minute...</p>
        <div className="space-y-2 text-sm text-zinc-500">
          <p>🔍 Analyzing stance and footwork</p>
          <p>👊 Evaluating offensive combinations</p>
          <p>🛡️ Assessing defensive technique</p>
          <p>📊 Generating personalized drills</p>
        </div>
      </div>
    );
  }

  if (step === 'success') {
    return (
      <div className="max-w-2xl mx-auto py-12 text-center animate-fade-in">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-600/15 rounded-full mb-6 border border-emerald-600/20">
          <CheckCircle2 className="w-8 h-8 text-emerald-400" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Analysis Complete!</h2>
        <p className="text-zinc-400 mb-8">Your performance analysis and personalized drills are ready.</p>
        <Button
          onClick={() => navigate(`/analysis/${sessionId}`)}
          size="lg"
          className="mb-3"
        >
          View Detailed Analysis
        </Button>
        <Button
          onClick={() => {
            setStep('form');
            setFormData({ title: '', description: '', match_context: 'training', opponent_style: 'balanced', matchDescription: '' });
            setSessionId(null);
          }}
          variant="secondary"
        >
          Analyze Another Match
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl animate-fade-in">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white mb-2">Analyze Match Performance</h1>
        <p className="text-zinc-400">Upload match details for instant AI-powered analysis and personalized coaching feedback</p>
      </div>

      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <Upload className="w-4 h-4 text-red-400" />
            Match Details
          </h2>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Match Title</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
                placeholder="e.g., Sparring Session with Coach Martinez"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Description</label>
              <input
                type="text"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Brief context about the match (optional)"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">Match Type</label>
                <select
                  value={formData.match_context}
                  onChange={(e) => setFormData({ ...formData, match_context: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors"
                >
                  <option value="training">Training</option>
                  <option value="sparring">Sparring</option>
                  <option value="amateur">Amateur Fight</option>
                  <option value="pro">Professional Fight</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">Opponent Style</label>
                <select
                  value={formData.opponent_style}
                  onChange={(e) => setFormData({ ...formData, opponent_style: e.target.value })}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors"
                >
                  <option value="balanced">Balanced</option>
                  <option value="aggressive">Aggressive</option>
                  <option value="defensive">Defensive</option>
                  <option value="counter">Counter-Puncher</option>
                  <option value="brawler">Brawler</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Match Summary</label>
              <textarea
                value={formData.matchDescription}
                onChange={(e) => setFormData({ ...formData, matchDescription: e.target.value })}
                required
                placeholder="Describe key moments: How did the fight flow? What went well? What challenges did you face? Include details about your stance, combinations thrown, defense etc."
                rows={6}
                className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2.5 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/50 transition-colors resize-none"
              />
            </div>

            {error && (
              <div className="bg-red-900/20 border border-red-800 rounded-lg px-3 py-2.5 text-red-400 text-sm">
                {error}
              </div>
            )}

            <Button type="submit" loading={loading} className="w-full" size="lg">
              Analyze Performance
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="mt-6">
        <CardHeader>
          <h3 className="text-sm font-semibold text-white">Tips for Best Results</h3>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-zinc-400">
            <li className="flex gap-2">
              <span className="text-red-400 flex-shrink-0">•</span>
              <span>Be specific about your performance and what you observed</span>
            </li>
            <li className="flex gap-2">
              <span className="text-red-400 flex-shrink-0">•</span>
              <span>Mention specific combinations or techniques you used</span>
            </li>
            <li className="flex gap-2">
              <span className="text-red-400 flex-shrink-0">•</span>
              <span>Note any defensive challenges or opportunities you missed</span>
            </li>
            <li className="flex gap-2">
              <span className="text-red-400 flex-shrink-0">•</span>
              <span>Include details about footwork and positioning</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
