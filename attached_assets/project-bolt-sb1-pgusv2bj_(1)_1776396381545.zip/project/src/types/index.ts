export type ExperienceLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'Pro';
export type Stance = 'Orthodox' | 'Southpaw' | 'Switch';
export type SessionStatus = 'pending' | 'processing' | 'completed' | 'failed';
export type DrillDifficulty = 'Easy' | 'Medium' | 'Hard';
export type DrillCategory = 'footwork' | 'offense' | 'defense' | 'stamina' | 'combination' | 'general';

export interface BoxerProfile {
  id: string;
  user_id: string;
  name: string;
  weight_class: string;
  experience_level: ExperienceLevel;
  stance: Stance;
  age: number | null;
  reach_inches: number | null;
  created_at: string;
}

export interface MatchSession {
  id: string;
  boxer_id: string;
  title: string;
  description: string;
  video_url: string;
  match_context: string;
  opponent_style: string;
  status: SessionStatus;
  created_at: string;
  performance_analyses?: PerformanceAnalysis[];
}

export interface PerformanceAnalysis {
  id: string;
  session_id: string;
  overall_score: number;
  stance_score: number;
  offense_score: number;
  defense_score: number;
  footwork_score: number;
  combination_score: number;
  stance_feedback: string;
  offense_feedback: string;
  defense_feedback: string;
  footwork_feedback: string;
  combination_feedback: string;
  tactical_summary: string;
  key_strengths: string[];
  improvement_areas: string[];
  shot_accuracy: number;
  punches_thrown: number;
  punches_landed: number;
  created_at: string;
  drill_recommendations?: DrillRecommendation[];
}

export interface DrillRecommendation {
  id: string;
  analysis_id: string | null;
  boxer_id: string;
  category: DrillCategory;
  name: string;
  description: string;
  duration: string;
  difficulty: DrillDifficulty;
  focus_area: string;
  reps: string;
  completed: boolean;
  created_at: string;
}

export interface ProgressMetric {
  id: string;
  boxer_id: string;
  session_date: string;
  overall_score: number;
  stance_score: number;
  offense_score: number;
  defense_score: number;
  footwork_score: number;
  notes: string;
  created_at: string;
}

export interface AnalyzeMatchRequest {
  session_id: string;
  boxer_profile: BoxerProfile;
  match_context: string;
  opponent_style: string;
  match_description: string;
}
