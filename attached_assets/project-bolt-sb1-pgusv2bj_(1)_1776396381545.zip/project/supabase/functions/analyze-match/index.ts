import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface AnalyzeMatchRequest {
  session_id: string;
  boxer_profile: {
    id: string;
    name: string;
    stance: string;
    experience_level: string;
    weight_class: string;
  };
  match_context: string;
  opponent_style: string;
  match_description: string;
}

interface AnalysisResult {
  overall_score: number;
  stance_score: number;
  offense_score: number;
  defense_score: number;
  footwork_score: number;
  combination_score: number;
  stance_feedback: string;
  offense_feedback: string;
  defense_feedback: string;
  footwork_feedback: string;
  combination_feedback: string;
  tactical_summary: string;
  key_strengths: string[];
  improvement_areas: string[];
  shot_accuracy: number;
  punches_thrown: number;
  punches_landed: number;
  drills: Drill[];
}

interface Drill {
  category: string;
  name: string;
  description: string;
  duration: string;
  difficulty: string;
  focus_area: string;
  reps: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body: AnalyzeMatchRequest = await req.json();
    const { session_id, boxer_profile, match_context, opponent_style, match_description } = body;

    const supabaseUrl = Deno.env.get("SUPABASE_URL") as string;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") as string;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Update session to processing
    await supabase
      .from("match_sessions")
      .update({ status: "processing" })
      .eq("id", session_id);

    // Build prompt
    const systemPrompt = `You are an elite boxing coach AI with expertise in technical analysis of boxing performance.
You analyze match descriptions and provide detailed, actionable coaching feedback.
Always respond with valid JSON matching the specified schema.
Your scoring is rigorous: 70+ is good, 80+ is excellent, 90+ is elite.`;

    const userPrompt = `Analyze the following boxing performance and provide scores and tactical feedback.

BOXER PROFILE:
- Name: ${boxer_profile.name}
- Stance: ${boxer_profile.stance}
- Experience: ${boxer_profile.experience_level}
- Weight Class: ${boxer_profile.weight_class}

MATCH CONTEXT: ${match_context}
OPPONENT STYLE: ${opponent_style}

MATCH DESCRIPTION / OBSERVATIONS:
${match_description}

Return a JSON object with this exact structure:
{
  "overall_score": <0-100>,
  "stance_score": <0-100>,
  "offense_score": <0-100>,
  "defense_score": <0-100>,
  "footwork_score": <0-100>,
  "combination_score": <0-100>,
  "stance_feedback": "<2-3 sentences on stance and guard>",
  "offense_feedback": "<2-3 sentences on punching offense>",
  "defense_feedback": "<2-3 sentences on defensive technique>",
  "footwork_feedback": "<2-3 sentences on movement and footwork>",
  "combination_feedback": "<2-3 sentences on combinations and flow>",
  "tactical_summary": "<3-4 sentence overall tactical assessment>",
  "key_strengths": ["<strength 1>", "<strength 2>", "<strength 3>"],
  "improvement_areas": ["<area 1>", "<area 2>", "<area 3>"],
  "shot_accuracy": <0-100 percentage>,
  "punches_thrown": <estimated integer>,
  "punches_landed": <estimated integer>,
  "drills": [
    {
      "category": "<footwork|offense|defense|stamina|combination>",
      "name": "<drill name>",
      "description": "<what to do and why>",
      "duration": "<e.g. 3 x 3-minute rounds>",
      "difficulty": "<Easy|Medium|Hard>",
      "focus_area": "<specific technique being trained>",
      "reps": "<e.g. 10 reps per side>"
    }
  ]
}`;

    const openaiKey = Deno.env.get("OPENAI_API_KEY");
    if (!openaiKey) {
      throw new Error("OPENAI_API_KEY not configured");
    }

    const aiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openaiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.5,
        max_tokens: 2000,
      }),
    });

    if (!aiResponse.ok) {
      const errText = await aiResponse.text();
      throw new Error(`OpenAI API error: ${aiResponse.status} ${errText}`);
    }

    const aiResult = await aiResponse.json();
    const analysisText = aiResult.choices[0]?.message?.content;

    if (!analysisText) {
      throw new Error("No response from OpenAI");
    }

    let analysis: AnalysisResult;
    try {
      const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) throw new Error("No JSON found in response");
      analysis = JSON.parse(jsonMatch[0]);
    } catch (e) {
      console.error("Failed to parse AI response:", analysisText);
      throw new Error("Failed to parse AI analysis response");
    }

    // Insert performance analysis
    const { data: analysisData, error: analysisErr } = await supabase
      .from("performance_analyses")
      .insert({
        session_id,
        overall_score: analysis.overall_score,
        stance_score: analysis.stance_score,
        offense_score: analysis.offense_score,
        defense_score: analysis.defense_score,
        footwork_score: analysis.footwork_score,
        combination_score: analysis.combination_score,
        stance_feedback: analysis.stance_feedback,
        offense_feedback: analysis.offense_feedback,
        defense_feedback: analysis.defense_feedback,
        footwork_feedback: analysis.footwork_feedback,
        combination_feedback: analysis.combination_feedback,
        tactical_summary: analysis.tactical_summary,
        key_strengths: analysis.key_strengths,
        improvement_areas: analysis.improvement_areas,
        shot_accuracy: analysis.shot_accuracy,
        punches_thrown: analysis.punches_thrown,
        punches_landed: analysis.punches_landed,
      })
      .select()
      .single();

    if (analysisErr) throw analysisErr;

    // Insert drills
    if (analysis.drills && analysis.drills.length > 0) {
      const drills = analysis.drills.map((d) => ({
        analysis_id: analysisData.id,
        boxer_id: boxer_profile.id,
        category: d.category,
        name: d.name,
        description: d.description,
        duration: d.duration,
        difficulty: d.difficulty,
        focus_area: d.focus_area,
        reps: d.reps,
        completed: false,
      }));

      const { error: drillsErr } = await supabase
        .from("drill_recommendations")
        .insert(drills);

      if (drillsErr) console.error("Drills insert error:", drillsErr);
    }

    // Insert progress metric
    await supabase.from("progress_metrics").insert({
      boxer_id: boxer_profile.id,
      session_date: new Date().toISOString().split("T")[0],
      overall_score: analysis.overall_score,
      stance_score: analysis.stance_score,
      offense_score: analysis.offense_score,
      defense_score: analysis.defense_score,
      footwork_score: analysis.footwork_score,
    });

    // Update session to completed
    await supabase
      .from("match_sessions")
      .update({ status: "completed" })
      .eq("id", session_id);

    return new Response(
      JSON.stringify({ success: true, analysis: analysisData }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error("Function error:", message);

    return new Response(
      JSON.stringify({ error: message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
