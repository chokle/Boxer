/*
  # Add user_id to boxer_profiles and configure RLS policies

  ## Summary
  Links boxer_profiles to Supabase Auth users via a user_id column, and sets up
  Row Level Security policies so each user can only access their own data across
  all tables.

  ## Changes
  1. boxer_profiles - Add user_id foreign key to auth.users
  2. RLS Policies - Configure SELECT/INSERT/UPDATE/DELETE for all 5 tables

  ## Security
  - All tables have RLS enabled (already set)
  - Policies use auth.uid() to enforce per-user data isolation
  - No user can read, write, or modify another user's data
*/

ALTER TABLE public.boxer_profiles
  ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;

CREATE UNIQUE INDEX IF NOT EXISTS boxer_profiles_user_id_key ON public.boxer_profiles(user_id);

-- boxer_profiles policies
CREATE POLICY "Users can view own boxer profile"
  ON public.boxer_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own boxer profile"
  ON public.boxer_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own boxer profile"
  ON public.boxer_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- match_sessions policies
CREATE POLICY "Users can view own match sessions"
  ON public.match_sessions FOR SELECT
  TO authenticated
  USING (
    boxer_id IN (
      SELECT id FROM public.boxer_profiles WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own match sessions"
  ON public.match_sessions FOR INSERT
  TO authenticated
  WITH CHECK (
    boxer_id IN (
      SELECT id FROM public.boxer_profiles WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own match sessions"
  ON public.match_sessions FOR UPDATE
  TO authenticated
  USING (
    boxer_id IN (
      SELECT id FROM public.boxer_profiles WHERE user_id = auth.uid()
    )
  );

-- performance_analyses policies
CREATE POLICY "Users can view own performance analyses"
  ON public.performance_analyses FOR SELECT
  TO authenticated
  USING (
    session_id IN (
      SELECT ms.id FROM public.match_sessions ms
      JOIN public.boxer_profiles bp ON ms.boxer_id = bp.id
      WHERE bp.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own performance analyses"
  ON public.performance_analyses FOR INSERT
  TO authenticated
  WITH CHECK (
    session_id IN (
      SELECT ms.id FROM public.match_sessions ms
      JOIN public.boxer_profiles bp ON ms.boxer_id = bp.id
      WHERE bp.user_id = auth.uid()
    )
  );

-- drill_recommendations policies
CREATE POLICY "Users can view own drill recommendations"
  ON public.drill_recommendations FOR SELECT
  TO authenticated
  USING (
    boxer_id IN (
      SELECT id FROM public.boxer_profiles WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own drill recommendations"
  ON public.drill_recommendations FOR INSERT
  TO authenticated
  WITH CHECK (
    boxer_id IN (
      SELECT id FROM public.boxer_profiles WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own drill recommendations"
  ON public.drill_recommendations FOR UPDATE
  TO authenticated
  USING (
    boxer_id IN (
      SELECT id FROM public.boxer_profiles WHERE user_id = auth.uid()
    )
  )
  WITH CHECK (
    boxer_id IN (
      SELECT id FROM public.boxer_profiles WHERE user_id = auth.uid()
    )
  );

-- progress_metrics policies
CREATE POLICY "Users can view own progress metrics"
  ON public.progress_metrics FOR SELECT
  TO authenticated
  USING (
    boxer_id IN (
      SELECT id FROM public.boxer_profiles WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own progress metrics"
  ON public.progress_metrics FOR INSERT
  TO authenticated
  WITH CHECK (
    boxer_id IN (
      SELECT id FROM public.boxer_profiles WHERE user_id = auth.uid()
    )
  );
