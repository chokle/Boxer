/*
  # Fix RLS Policy Security Issues

  ## Summary
  Remove all insecure "Allow public" policies that have always-true conditions.
  Keep only the secure policies that check user ownership via auth.uid().

  ## Changes
  - Drop all INSERT/UPDATE policies with always-true conditions
  - Retain only authenticated user ownership-based policies
*/

-- Drop insecure policies from boxer_profiles
DROP POLICY IF EXISTS "Allow public insert on boxer_profiles" ON public.boxer_profiles;
DROP POLICY IF EXISTS "Allow public update on boxer_profiles" ON public.boxer_profiles;

-- Drop insecure policies from match_sessions
DROP POLICY IF EXISTS "Allow public insert on match_sessions" ON public.match_sessions;
DROP POLICY IF EXISTS "Allow public update on match_sessions" ON public.match_sessions;

-- Drop insecure policies from performance_analyses
DROP POLICY IF EXISTS "Allow public insert on performance_analyses" ON public.performance_analyses;
DROP POLICY IF EXISTS "Allow public update on performance_analyses" ON public.performance_analyses;

-- Drop insecure policies from drill_recommendations
DROP POLICY IF EXISTS "Allow public insert on drill_recommendations" ON public.drill_recommendations;
DROP POLICY IF EXISTS "Allow public update on drill_recommendations" ON public.drill_recommendations;

-- Drop insecure policies from progress_metrics
DROP POLICY IF EXISTS "Allow public insert on progress_metrics" ON public.progress_metrics;
DROP POLICY IF EXISTS "Allow public update on progress_metrics" ON public.progress_metrics;
